import time 
import cv2
from cv2 import flann_Index
from cv2 import FlannBasedMatcher_create
from cv2 import FlannBasedMatcher
import numpy as np
import matplotlib.pyplot as plt

# Threshold 
MIN_MATCH_COUNT=10

# Initiate SIFT detector
sift=cv2.xfeatures2d.SIFT_create()



# start capturing video
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    red = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)   # turn the frame captured into grayscale
    kp1, desc1 = sift.detectAndCompute(red,None)
    
    kp2, desc2 = sift.detectAndCompute(gray,None)   # find the keypoints and descriptors with SIFT  of the frame captured
    
    # Obtain matches using K-Nearest Neighbor Method
    # the result 'matches' is the number of similar matches found in both images
    bf = cv2.BFMatcher()
    matches=bf.knnMatch(desc2,desc1,k=2)


    # store all the good matches as per Lowe's ratio test.
    goodMatch=[]
    for m,n in matches:
        if(m.distance<0.75*n.distance):
            goodMatch.append(m)


    # If enough matches are found, we extract the locations of matched keypoints 
    # in both the images.
    # They are passed to find the perpective transformation.
    # Once we get this 3x3 transformation matrix, we use it to transform the corners 
    # of query image to corresponding points in train image. Then we draw it.

    if(len(goodMatch)>MIN_MATCH_COUNT):
        tp=[]  # src_pts
        qp=[]  # dst_pts
        for m in goodMatch:
            tp.append(kp1[m.trainIdx].pt)
            qp.append(kp2[m.queryIdx].pt)
        tp,qp=np.float32((tp,qp))

        H,status=cv2.findHomography(tp,qp,cv2.RANSAC,3.0)

        train_img =  cv2.imread('res/obama1.jpg')
        # train=cv2.imread('C:/Users/Payal Kadav/Downloads/SIFT-Scale-Invariant-Feature-Transform-master/SIFT-Scale-Invariant-Feature-Transform-master/res/train.jpg')
        w, h, _ = train_img.shape
        train_outline= np.float32([[[0,0],[0,h-1],[w-1,h-1],[w-1,0]]])
        query_outline = cv2.perspectiveTransform(train_outline,H)

        cv2.polylines(frame,[np.int32(query_outline)],True,(0,255,0),5)
        cv2.putText(frame,'Object Found',(50,50), cv2.FONT_HERSHEY_COMPLEX, 2 ,(0,255,0), 2)
        print("Match Found-")
        print(len(goodMatch),MIN_MATCH_COUNT)

    else:
        print("Not Enough match found-")
        print(len(goodMatch),MIN_MATCH_COUNT)
    cv2.imshow('result',frame)

    if cv2.waitKey(1) == 13:
        break
cap.release()
cv2.destroyAllWindows()


